const GreenNFTData = artifacts.require("./GreenNFTData.sol");

module.exports = async function(deployer, network, accounts) {
    await deployer.deploy(GreenNFTData);
};
